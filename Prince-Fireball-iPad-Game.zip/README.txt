# Prince Fireball

A browser-based iPad landscape platform game.

## Run it
Open `index.html` in Safari or upload the folder to any web host.

## iPad controls
- Bottom left: move left/right
- Bottom right: jump / shoot green fireballs
- The game automatically asks the player to rotate to landscape mode.

Enemies:
- Robo Rat
- Forky
- Sludge Brain
