Belfast Streets Web Prototype
Open index.html in a modern browser. For iPhone/iPad, the files need to be hosted on a website or opened through a compatible local web server.